# variables 
blanks = ["__1__", "__2__","__3__","__4__"]

easy_paragraph ='The 2018 World Cup opened between __1__ and Saudi Arabia and record the biggest __2__ by __3__ five vs __4__.'
medium_paragraph ='Russia moved to  brink of __1__ for the last 16 of the __2__ Cup after __3__ nation beat __4__ in St Petersburg.'
hard_paragraph ='Programmers are __1__ enthusiasts, who communicate with the computer __2__ by writing __3__, and are always developing __4__ for the computer.'

easy_answers = ["Russia", "win", "host", "zero"]
medium_answers = ["qualifying", "World", "host", "Egypt"]
hard_answers = ["computer", "system", "codes", "software"]

# Helper Functions
#this funchtion let the user to choose his own game level
# input:
# there is madlibs will ask the user to coose his own level
# there is an if statment will call the exact function based on the user input.
def getYourlevel():
    userInput = raw_input('To group all the paragraphs and answers together. choose your won level : easy / medium / hard ')

    if userInput == 'easy':
        getAnswer(easy_paragraph, easy_answers)
    elif userInput == 'medium':
        getAnswer(medium_paragraph, medium_answers)
    elif userInput == 'hard':
        getAnswer(hard_paragraph, hard_answers)

    else:
        print 'wrong choose'
        

def getAnswer(paragraph, answers):
    print paragraph
    for elm in range(0, len(answers)):
        userInput = raw_input('what is in the blanks? ')
        while userInput != answers[elm]:
            print 'try again'
            userInput = raw_input('what is in the blanks? ')
        if userInput ==answers[elm]:
            print 'yes , you got it '
            paragraph = paragraph.replace(blanks[elm], answers[elm])
            print paragraph
